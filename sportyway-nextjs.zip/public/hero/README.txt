Place hero image here as hero.jpg
