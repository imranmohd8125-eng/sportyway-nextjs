Place product images here, named jersey-1.jpg ... jersey-12.jpg
